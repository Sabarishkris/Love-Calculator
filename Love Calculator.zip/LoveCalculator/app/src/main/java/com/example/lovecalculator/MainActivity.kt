package com.example.lovecalculator

import android.app.Activity
import android.content.Intent
import android.content.pm.ActivityInfo
import android.os.Bundle
import android.widget.Toast

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

import com.example.lovecalculator.databinding.ActivityMainBinding
import com.example.lovecalculator.databinding.ActivityResultBinding
import kotlin.math.abs

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private lateinit var binding1: ActivityResultBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        requestedOrientation=ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        binding1 = ActivityResultBinding.inflate(layoutInflater)
        binding.calculate.setOnClickListener {
            Toast.makeText(this, "CLicked", Toast.LENGTH_SHORT).show()
            calculate()
        }
    }

    private fun calculate() {
        val name1 = binding.Name.text.toString()
        val name2 = binding.partnerName.text.toString()

        if (name1.isNotEmpty() && name2.isNotEmpty()) {
            Toast.makeText(this,"passed",Toast.LENGTH_SHORT).show()
            val intent= Intent(this, Result::class.java)
            intent.putExtra("name1", name1)
            intent.putExtra("name2", name2)
            startActivity(intent)
            finish()
        } else {
            Toast.makeText(this, "Please enter names in both fields", Toast.LENGTH_SHORT).show()
        }
    }

}