package com.example.lovecalculator

import android.content.Intent
import android.os.Bundle

import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

import com.example.lovecalculator.databinding.ActivityResultBinding
import kotlin.math.abs

class Result : AppCompatActivity() {
    private lateinit var binding1: ActivityResultBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding1 = ActivityResultBinding.inflate(layoutInflater)
        setContentView(binding1.root)
        setSupportActionBar(binding1.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        val name1 = intent.getStringExtra("name1")
        val name2=intent.getStringExtra("name2")

        var num: Int = abs(name1.hashCode() - name2.hashCode()) % 101
        val image = when {
            num <= 50 -> R.drawable.feel
            num <= 85 -> R.drawable.done
            else -> R.drawable.hug
        }

        val belowText = when {
            num <= 50 -> "Can choose someone better"
            num <= 85 -> "OK"
            else -> "Perfect Pair"
        }
        binding1.belowText.text = belowText
        binding1.percentage.text = "$num %"
        binding1.gif.setImageResource(image)
    }

}
